USE nerdygadgets; 

DROP TABLE IF EXISTS aanbevelingen; 
CREATE TABLE IF NOT EXISTS aanbevelingen (
GroepID INT NOT NULL primary key auto_increment,
GroepNaam VARCHAR(35) NOT NULL,
AanbevolenGroep1 int,
AanbevolenGroep2 int,
AanbevolenGroep3 int,
AanbevolenGroep4 int
); 

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1, AanbevolenGroep2)
VALUES (1, 'Shirts', 2, 3);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1, AanbevolenGroep2)
VALUES (2, 'Hoodies', 1, 3);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1, AanbevolenGroep2)
VALUES (3, 'Voet-wear', 1, 2);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1, AanbevolenGroep2, AanbevolenGroep3)
VALUES (4, 'Verpakking', 5, 6, 7);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1, AanbevolenGroep2, AanbevolenGroep3, AanbevolenGroep4)
VALUES (5, 'Verpakking_machines', 4, 6, 7, 8);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1, AanbevolenGroep2, AanbevolenGroep3)
VALUES (6, 'Verpakking_tools', 4, 5, 7);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1, AanbevolenGroep2, AanbevolenGroep3)
VALUES (7, 'Bags&boxes', 4, 5, 6);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1)
VALUES (8, 'Replacements', 5);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1)
VALUES (9, 'Snacks', 10);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1, AanbevolenGroep2)
VALUES (10, 'Mugs', 9, 12);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1)
VALUES (11, 'Toys', 12);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1)
VALUES (12, 'USB', 10);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1)
VALUES (13, 'Overig_despatch_tape', 4);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1)
VALUES (14, 'Overig_halloween', 14);

insert into aanbevelingen (GroepID, GroepNaam, AanbevolenGroep1)
VALUES (15, 'Overig_periscope', 11);



DROP TABLE IF EXISTS globalcoupons; 
CREATE TABLE IF NOT EXISTS `globalcoupons` (
`globalCouponCode` varchar(45) NOT NULL,
`uses` int(8) DEFAULT NULL,
`validUntil` datetime DEFAULT NULL,
`kortingsPercentage` int(2) DEFAULT NULL,
PRIMARY KEY (`globalCouponCode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


INSERT INTO globalCoupons
VALUES ("Kerst", 2147483503, "2023-12-27", 20);

INSERT INTO globalCoupons
VALUES ("Test", 2147483643, "2023-12-31", 20);

INSERT INTO globalCoupons
VALUES ("Verlopen", 2147483647, "2023-11-20", 15);

INSERT INTO globalCoupons
VALUES ("Appelsappie", 2147483647, "2024-12-31", 99);



DROP TABLE IF EXISTS reviews; 
CREATE TABLE reviews ( 
id INT AUTO_INCREMENT PRIMARY KEY, 
StockItemID INT, 
rating INT, 
beschrijving TEXT, 
time TIME, 
date DATE, 
PersonID INT, 
Anoniem BOOLEAN, 
FOREIGN KEY (StockItemID) REFERENCES stockitems (StockItemID), 
FOREIGN KEY (PersonID) REFERENCES people (PersonID) 
) ENGINE=InnoDB; 



update stockitems SET groepID = 1
where StockitemName like '%shirt%';

UPDATE stockitems SET groepID = 2
WHERE StockitemName LIKE '%hoodie%';

UPDATE stockitems SET groepID = 2
WHERE StockitemName LIKE'%jacket%';

update stockitems SET groepID = 3
where StockitemName like '%slipper%';

update stockitems SET groepID = 3
where StockitemName like '%socks%';

update stockitems SET groepID = 4
where StockitemName like '%bubble wrap%';

update stockitems SET groepID = 4
where StockitemName like '%bubblewrap%';

update stockitems SET groepID = 4
where StockitemName like '%Air cushion film%';

update stockitems SET groepID = 4
where StockitemName like '%void fill%';

update stockitems SET groepID = 5
where StockitemName like '%machine%';

update stockitems SET groepID = 5
where StockitemName like '%dispenser%';

update stockitems SET groepID = 6
where StockitemName like '%knife%';

update stockitems SET groepID = 6
where StockitemName like'%marker%';

update stockitems SET groepID = 6
where StockitemName like'%packaging tape%';

update stockitems SET groepID = 7
where StockitemName like '%post bag%';

update stockitems SET groepID = 7
where StockitemName like '%carton%';

update stockitems SET groepID = 7
where StockitemName like '%post box%';

update stockitems SET groepID = 8
where StockitemName like '%replacement%';

update stockitems SET groepID = 9
where StockitemName like '%chocolate%';

update stockitems SET groepID = 10
where StockitemName like '%mug%';

update stockitems SET groepID = 11
where StockItemName like '%RC%';

update stockitems SET groepID = 11
where StockItemName like'%Ride%';

update stockitems SET groepID = 11
where StockItemName like'%action figures%';

update stockitems SET groepID = 12
where StockitemName like '%usb%';

update stockitems SET groepID = 13
where StockitemName like '%despatch%';

update stockitems SET groepID = 14
where StockitemName like '%halloween%';

update stockitems SET groepID = 15
where StockitemName like '%periscope%';



ALTER TABLE orders 
ADD COLUMN StockItemID INT, 
ADD CONSTRAINT FK_StockItemID 
FOREIGN KEY (StockItemID) 
REFERENCES stockitems(StockItemID) 
ON DELETE NO ACTION 
ON UPDATE NO ACTION; 


ALTER TABLE stockitems
Add GroepID int;