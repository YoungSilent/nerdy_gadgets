use nerdygadgets;
DROP TABLE IF EXISTS reviews;
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    StockItemID INT,
    rating INT,
    beschrijving TEXT,
    time TIME,
    date DATE,
    PersonID INT,
    Anoniem BOOLEAN,
    FOREIGN KEY (StockItemID) REFERENCES stockitems (StockItemID),
    FOREIGN KEY (PersonID) REFERENCES people (PersonID)
);
DROP PROCEDURE IF EXISTS insert_reviews_for_all_items;
DELIMITER //
CREATE PROCEDURE insert_reviews_for_all_items()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE temp_StockItemID INT;
    DECLARE rand_rating INT;
    DECLARE rand_date DATE;
    DECLARE lorem_ipsum VARCHAR(255);
    DECLARE cur_stockItems CURSOR FOR
        SELECT DISTINCT StockItemID FROM StockItems;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    OPEN cur_stockItems;
    my_loop: LOOP
        FETCH cur_stockItems INTO temp_StockItemID;
        IF done THEN
            LEAVE my_loop;
        END IF;
        -- voeg willekeurige reviews toe
        SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 1046, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 1045, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 1249, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 2277, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 2253, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 2280, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 2279, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 3058, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 3147, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 3178, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
INSERT INTO reviews (`id`, `StockItemID`, `rating`, `beschrijving`, `time`, `date`, `PersonID`, `Anoniem`)
VALUES (NULL, temp_StockItemID, rand_rating, lorem_ipsum, '00:00:00', rand_date, 3209, NULL);
SET rand_rating = FLOOR(1 + RAND() * 10);
SET rand_date = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 365) DAY);
SET lorem_ipsum = CONCAT(
            SUBSTRING_INDEX('Lorem ipsum dolor sit', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('consectetur adipiscing elit sed', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('do eiusmod tempor incididunt', ' ', 1 + FLOOR(RAND() * 5)),
            ' ',
            SUBSTRING_INDEX('ut labore et dolore', ' ', 1 + FLOOR(RAND() * 5))
        );
    END LOOP;
    CLOSE cur_stockItems;
END //
DELIMITER ;
CALL insert_reviews_for_all_items();
ALTER TABLE orders
ADD COLUMN StockItemID INT,
ADD CONSTRAINT FK_StockItemID
FOREIGN KEY (StockItemID)
REFERENCES stockitems(StockItemID)
ON DELETE NO ACTION
ON UPDATE NO ACTION;