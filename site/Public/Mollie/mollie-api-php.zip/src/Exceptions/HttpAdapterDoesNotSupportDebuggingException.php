<?php

namespace Mollie\Api\Exceptions;

class HttpAdapterDoesNotSupportDebuggingException extends \Mollie\Api\Exceptions\ApiException
{
}
