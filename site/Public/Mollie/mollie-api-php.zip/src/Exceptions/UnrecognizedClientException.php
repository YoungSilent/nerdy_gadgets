<?php

namespace Mollie\Api\Exceptions;

class UnrecognizedClientException extends \Mollie\Api\Exceptions\ApiException
{
}
