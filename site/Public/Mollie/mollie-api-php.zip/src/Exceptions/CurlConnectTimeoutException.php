<?php

namespace Mollie\Api\Exceptions;

class CurlConnectTimeoutException extends \Mollie\Api\Exceptions\ApiException
{
}
