<?php

namespace Mollie\Api\Exceptions;

class UnrecognizedClientException extends ApiException
{
}
